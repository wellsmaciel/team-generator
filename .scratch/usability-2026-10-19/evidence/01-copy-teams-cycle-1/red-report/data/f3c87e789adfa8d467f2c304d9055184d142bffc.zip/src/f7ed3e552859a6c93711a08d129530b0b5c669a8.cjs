const { test, expect } = require('@playwright/test');

test('clicking Copy teams copies the current shareable text and confirms only after success', async ({ page }) => {
  await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  await page.goto('/');
  for (const [name, score] of [['Bruno', 2], ['Carla', 3], ['Diego', 4], ['Eva', 5]]) {
    await page.getByLabel('Player Name', { exact: true }).fill(name);
    await page.getByLabel('Player Skill', { exact: true }).fill(String(score));
    await page.getByRole('button', { name: 'Add Player', exact: true }).click();
  }
  const participants = page.locator('#playerSkillList input[type=checkbox]');
  for (const checkbox of await participants.all()) await checkbox.check();
  await page.getByRole('button', { name: 'Generate Teams', exact: true }).click();
  await expect(page.locator('#shareControls')).toBeVisible();

  const expectedText = await page.getByLabel('Teams to copy').inputValue();

  await page.getByRole('button', { name: 'Copy teams', exact: true }).click();

  await expect(page.getByRole('status').filter({ hasText: /copied/i })).toBeVisible();
  const clipboardText = await page.evaluate(() => navigator.clipboard.readText());
  expect(clipboardText).toBe(expectedText);
});
