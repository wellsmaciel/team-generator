const { test, expect } = require('@playwright/test');

test('clicking Copy teams copies the current shareable text and confirms only after success', async ({ page }) => {
  await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  await page.goto('/');
  for (const [name, score] of [['Bruno', 2], ['Carla', 3], ['Diego', 4], ['Eva', 5]]) {
    await page.getByLabel('Player Name', { exact: true }).fill(name);
    await page.getByLabel('Player Skill', { exact: true }).fill(String(score));
    await page.getByRole('button', { name: 'Add Player', exact: true }).click();
  }
  const participants = page.locator('#playerSkillList input[type=checkbox]');
  for (const checkbox of await participants.all()) await checkbox.check();
  await page.getByRole('button', { name: 'Generate Teams', exact: true }).click();
  await expect(page.locator('#shareControls')).toBeVisible();

  const expectedText = await page.getByLabel('Teams to copy').inputValue();

  await page.getByRole('button', { name: 'Copy teams', exact: true }).click();

  await expect(page.getByRole('status').filter({ hasText: /copied/i })).toBeVisible();
  const clipboardText = await page.evaluate(() => navigator.clipboard.readText());
  expect(clipboardText.replace(/\r\n/g, '\n')).toBe(expectedText);
});

test('clipboard rejection offers manual copying without losing the displayed teams or players', async ({ page }) => {
  await page.goto('/');
  for (const [name, score] of [['Bruno', 2], ['Carla', 3], ['Diego', 4], ['Eva', 5]]) {
    await page.getByLabel('Player Name', { exact: true }).fill(name);
    await page.getByLabel('Player Skill', { exact: true }).fill(String(score));
    await page.getByRole('button', { name: 'Add Player', exact: true }).click();
  }
  const participants = page.locator('#playerSkillList input[type=checkbox]');
  for (const checkbox of await participants.all()) await checkbox.check();
  await page.getByRole('button', { name: 'Generate Teams', exact: true }).click();
  await expect(page.locator('#shareControls')).toBeVisible();
  const shareText = page.getByLabel('Teams to copy');
  const expectedText = await shareText.inputValue();
  const expectedTeams = await page.locator('#teamsContainer').innerText();

  // Simulate rejection only at the external clipboard API boundary.
  await page.evaluate(() => {
    navigator.clipboard.writeText = async () => {
      throw new DOMException('Clipboard access denied for this test.', 'NotAllowedError');
    };
  });
  await page.getByRole('button', { name: 'Copy teams', exact: true }).click();

  await expect(page.getByRole('status').filter({ hasText: /^Teams copied\.$/ })).toHaveCount(0);
  await expect(shareText).toBeVisible();
  await expect(shareText).toHaveValue(expectedText);
  await expect(shareText).toHaveAttribute('readonly', '');
  await expect(page.locator('#teamsContainer')).toHaveText(expectedTeams, { useInnerText: true });
  await expect(page.locator('#playerSkillList label')).toHaveText([
    'Bruno - 2', 'Carla - 3', 'Diego - 4', 'Eva - 5',
  ]);
  await expect(page.getByRole('status').filter({
    hasText: /copy[\s\S]*manually|manually[\s\S]*copy|select[\s\S]*copy/i,
  })).toBeVisible();
});

test('a pending less-balanced preview hides Copy teams and clears a previous copy status', async ({ page }) => {
  await page.context().grantPermissions(['clipboard-read', 'clipboard-write']);
  await page.goto('/');
  for (const [name, score] of [['Bruno', 2], ['Carla', 3], ['Diego', 4], ['Eva', 5]]) {
    await page.getByLabel('Player Name', { exact: true }).fill(name);
    await page.getByLabel('Player Skill', { exact: true }).fill(String(score));
    await page.getByRole('button', { name: 'Add Player', exact: true }).click();
  }
  const participants = page.locator('#playerSkillList input[type=checkbox]');
  for (const checkbox of await participants.all()) await checkbox.check();
  await page.getByRole('button', { name: 'Generate Teams', exact: true }).click();
  await expect(page.locator('#shareControls')).toBeVisible();

  await page.getByRole('button', { name: 'Copy teams', exact: true }).click();
  await expect(page.getByRole('status').filter({ hasText: /copied/i })).toBeVisible();

  await page.getByRole('button', { name: 'Generate another composition', exact: true }).click();
  await expect(page.locator('#alternativeControls')).toBeVisible();
  await expect(page.locator('#alternativeStatus')).toContainText('less balanced');

  await expect(page.locator('#shareControls')).toBeHidden();
  await expect(page.locator('#copyStatus')).toHaveText('');
});
